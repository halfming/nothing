		<footer>
   	<p>
      <a href="mailto:halfming@gmail.com" >halfming@gmail.com</a>
      <a href="/log.html" >log</a>
    </p>              
		</footer>
	</div>

</body>
</html>